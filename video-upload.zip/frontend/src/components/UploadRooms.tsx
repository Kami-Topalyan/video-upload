import type { RoomSummary } from "../types";

interface UploadRoomsProps {
  rooms: RoomSummary[];
  onSelect: (roomId: string) => void;
}

export function UploadRooms({ rooms, onSelect }: UploadRoomsProps) {
  return (
    <div className="p-4 flex-1 min-h-0 overflow-y-auto gap-5 flex flex-col">
      {rooms.map((room) => (
        <button
          key={room.id}
          type="button"
          className="border rounded-md p-4 cursor-pointer text-left bg-olive-300 flex flex-row justify-between"
          onClick={() => onSelect(room.id)}
        >
          <span className="text-black font-bold">{room.name}</span>
          <span className="text-black font-bold">{">"}</span>
        </button>
      ))}
    </div>
  );
}
